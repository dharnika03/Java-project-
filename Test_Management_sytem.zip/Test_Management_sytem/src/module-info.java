module Test_Management_sytem {
	requires java.desktop;
}